#!/bin/bash
apt update
# File harus SUDO
meow="Sealy" # rek rek aku teko rek
if [ "$EUID" -ne 0 ]; then
  echo "do sudo ./build_env.sh u silly $meow"
  exit 1
fi
# Installing ISO Maker tools (grub-mkrescue dependencies, including amd64 modules for ARM Mac hosts)
apt install -y grub-common grub-pc-bin xorriso mtools grub-efi-amd64-bin
# Create the directory structure for the ISO
mkdir -p iso/boot/grub
# Copy the Kernel and RootFS into the ISO boot folder
# (bzImage was created by kernel.sh, RootFS.gz was created by herta.sh)
cp bzImage iso/boot/
cp RootFS.gz iso/boot/
# Create the GRUB boot menu configuration
cat << 'EOF' > iso/boot/grub/grub.cfg
set timeout=10
set default=0

menuentry "Emergency Shell (Single Mode)" {
    # The 'single' parameter triggers our custom Single Mode in RootFS/init
    linux /boot/bzImage single console=ttyS0 console=tty0 root=/dev/ram0 rw
    initrd /boot/RootFS.gz
}

menuentry "HSS Secure Login (Multi Mode)" {
    # Normal boot triggers Multi Mode login
    linux /boot/bzImage console=ttyS0 console=tty0 root=/dev/ram0 rw
    initrd /boot/RootFS.gz
}
EOF
# Build the final bootable ISO image
grub-mkrescue -o aha.iso iso/
# Clean up the temporary iso directory
rm -rf iso/