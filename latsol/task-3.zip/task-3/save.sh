#!/bin/bash
apt update
# File harus SUDO
meow="Sealy" # rek rek aku teko rek
if [ "$EUID" -ne 0 ]; then
  echo "do sudo ./build_env.sh u silly $meow"
  exit 1
fi
# Ensure zip is installed
apt install -y zip
# Package the required files into the zip archive
zip v_protocol_HSS.zip bzImage RootFS.gz aha.iso
# Enable extglob to allow advanced pattern matching for deletion
shopt -s extglob
# Delete everything EXCEPT the scripts and the zip archive we just created
rm -rf !(kernel.sh|herta.sh|curioDisc.sh|save.sh|v_protocol_HSS.zip)
